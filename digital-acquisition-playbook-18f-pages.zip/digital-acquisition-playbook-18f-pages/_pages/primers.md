---
Title: (Primers) Basic Training for Cross-Functional Teams
issue: 9
--- 

Understanding these five practices and concepts can help improve the digital acquisition capability of your teams. These are:

* [Agile]({{site.baseurl}}/primers/agile)
* [Lean Startup]({{site.baseurl}}/primers/lean-startup)
* [Human-centered design]({{site.baseurl}}/primers/human-centered-design)
* [Open innovation]({{site.baseurl}}/primers/open-innovation)
* [Modular contracting]({{site.baseurl}}/primers/modular-contracting)
